### Stuck?

Please ask questions on [Stack Overflow](https://stackoverflow.com/questions/tagged/sinon) if you're stuck.

### Contribute

We really appreciate suggestions to improve the documentation so Sinon.JS can be easy to work with. Get in touch!
