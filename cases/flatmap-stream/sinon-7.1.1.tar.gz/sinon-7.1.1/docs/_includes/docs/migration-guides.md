### Migration guides

* Migrating from [v1.x to v2.0](/guides/migrating-to-2.0)
* Migrating from [v2.x to v3.0](/guides/migrating-to-3.0)
* Migrating from [v3.x to v4.0](/guides/migrating-to-4.0)
* Migrating from [v4.x to v5.0](/guides/migrating-to-5.0)
* Migrating from [v5.x to v6.0](/guides/migrating-to-6.0)

