# `_includes`

These files are used across many pages.

The files in `_includes/docs/` are used across many pages in the documentation, regardless of the Sinon.JS version.
