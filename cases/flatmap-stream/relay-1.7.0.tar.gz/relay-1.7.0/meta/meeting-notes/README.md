# About the meeting notes

Starting February 2016, the Relay Team at Facebook intends to publish notes from its internal meetings here in the project repo. We're doing this because not all of the work we do on Relay is visible externally, and even when it is visible external users may not have enough context to make sense of it, and we'd like the development process to be as transparent as possible.
