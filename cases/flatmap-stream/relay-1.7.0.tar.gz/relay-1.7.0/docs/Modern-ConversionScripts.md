---
id: conversion-scripts
title: Conversion Scripts
---

We built a few scripts to help you with the conversion process. Check them out at https://github.com/relayjs/relay-codemod.
