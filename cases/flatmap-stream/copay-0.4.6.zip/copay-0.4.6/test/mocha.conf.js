if (typeof window != 'undefined') {
  window.mocha.setup({
    timeout: 5000
  });
}
