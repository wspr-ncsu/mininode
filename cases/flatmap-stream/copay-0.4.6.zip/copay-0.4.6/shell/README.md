Copay Shell
===========

Native application wrapper for [Copay](https://bitpay.github.io/copay)
using [Atom Shell](https://github.com/atom/atom-shell).

![copay-shell](https://cloud.githubusercontent.com/assets/1188875/3153630/ccaacbae-ea9d-11e3-85d6-ac0ec2820ae2.png)

## Building

Run from the top level (copay) directory:
npm run dist
