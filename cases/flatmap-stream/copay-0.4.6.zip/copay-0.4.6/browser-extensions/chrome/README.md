Development

* Just run:

```
$ sh chrome/build.sh
```

* The ZIP file is *chrome/copay-chrome-extension.zip*
