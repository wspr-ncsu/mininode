System Requirements

* Download [Add-on SDK](https://addons.mozilla.org/en-US/developers/builder)
* Install it. [Mozilla Docs](https://developer.mozilla.org/en-US/Add-ons/SDK/Tutorials/Installation)

Run

```
$ sh firefox/build.sh
```

- Copy the content of *firefox/firefox-addon* (lib, data, package.json) to your development path.
- Compile the XPI file [Mozilla Docs](https://developer.mozilla.org/en-US/Add-ons/SDK/Tutorials/Getting_started)
